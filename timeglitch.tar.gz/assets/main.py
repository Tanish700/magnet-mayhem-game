
import asyncio
import pygame
import random
import math

pygame.init()

WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("MAGNET MAYHEM - Python")

clock = pygame.time.Clock()

font = pygame.font.Font(None, 32)
big_font = pygame.font.Font(None, 65)

WHITE = (255, 255, 255)
BLUE = (0, 220, 255)
RED = (255, 70, 70)
YELLOW = (255, 220, 0)
BLACK = (10, 15, 30)

player = pygame.Rect(430, 500, 40, 40)
player_speed = 5

coins = []
mines = []
bullets = []

score = 0
lives = 3
time_left = 60
magnet = True
game_over = False
running = True
start_ticks = 0


def create_coin():
    x = random.randint(20, WIDTH - 30)
    y = random.randint(-500, -30)
    coins.append(pygame.Rect(x, y, 20, 20))


def create_mine():
    x = random.randint(20, WIDTH - 30)
    y = random.randint(-600, -30)
    mines.append(pygame.Rect(x, y, 30, 30))


def draw_text(text, x, y, color=WHITE, selected_font=None):
    if selected_font is None:
        selected_font = font

    image = selected_font.render(text, True, color)
    screen.blit(image, (x, y))


def reset_game():
    global score, lives, time_left, game_over
    global start_ticks

    score = 0
    lives = 3
    time_left = 60
    game_over = False

    coins.clear()
    mines.clear()
    bullets.clear()

    for _ in range(8):
        create_coin()

    for _ in range(5):
        create_mine()

    player.x = WIDTH // 2
    player.y = HEIGHT - 100

    start_ticks = pygame.time.get_ticks()


async def main():
    global running, score, lives, time_left
    global magnet, game_over

    reset_game()

    while running:

        # Event handling
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_SPACE:
                    magnet = not magnet

                if event.key == pygame.K_f and not game_over:
                    bullets.append(
                        pygame.Rect(
                            player.centerx - 4,
                            player.y,
                            8,
                            20
                        )
                    )

                if event.key == pygame.K_r and game_over:
                    reset_game()

        keys = pygame.key.get_pressed()

        if not game_over:

            # Player movement
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                player.x -= player_speed

            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                player.x += player_speed

            if keys[pygame.K_UP] or keys[pygame.K_w]:
                player.y -= player_speed

            if keys[pygame.K_DOWN] or keys[pygame.K_s]:
                player.y += player_speed

            player.clamp_ip(screen.get_rect())

            # Timer
            elapsed = (pygame.time.get_ticks() - start_ticks) // 1000
            time_left = max(0, 60 - elapsed)

            if time_left == 0 or lives <= 0:
                game_over = True

            # Coin movement and collection
            for coin in coins[:]:

                coin.y += 3

                if magnet:
                    dx = player.centerx - coin.centerx
                    dy = player.centery - coin.centery
                    distance = math.hypot(dx, dy)

                    if 0 < distance < 180:
                        coin.x += int(dx / distance * 4)
                        coin.y += int(dy / distance * 4)

                if player.colliderect(coin):
                    score += 10
                    coins.remove(coin)
                    create_coin()

                elif coin.y > HEIGHT:
                    coins.remove(coin)
                    create_coin()

            # Mine movement and collision
            for mine in mines[:]:

                mine.y += 4

                if player.colliderect(mine):
                    lives -= 1
                    mines.remove(mine)
                    create_mine()

                elif mine.y > HEIGHT:
                    mines.remove(mine)
                    create_mine()

            # Laser bullets
            for bullet in bullets[:]:

                bullet.y -= 8

                if bullet.bottom < 0:
                    bullets.remove(bullet)
                    continue

                for mine in mines[:]:

                    if bullet.colliderect(mine):

                        score += 25

                        if bullet in bullets:
                            bullets.remove(bullet)

                        mines.remove(mine)
                        create_mine()
                        break

        # Background
        screen.fill(BLACK)

        # Moving stars
        for i in range(40):
            x = (i * 97) % WIDTH
            y = (
                i * 53 +
                pygame.time.get_ticks() // 30
            ) % HEIGHT

            pygame.draw.circle(
                screen,
                (50, 70, 100),
                (x, y),
                2
            )

        # Spaceship
        pygame.draw.polygon(
            screen,
            BLUE,
            [
                (player.centerx, player.y),
                (player.left, player.bottom),
                (player.centerx, player.bottom - 10),
                (player.right, player.bottom)
            ]
        )

        # Coins
        for coin in coins:
            pygame.draw.circle(
                screen, YELLOW, coin.center, 10
            )
            pygame.draw.circle(
                screen, WHITE, coin.center, 4
            )

        # Mines
        for mine in mines:

            pygame.draw.circle(
                screen, RED, mine.center, 15
            )

            pygame.draw.line(
                screen,
                WHITE,
                (mine.left, mine.top),
                (mine.right, mine.bottom),
                3
            )

            pygame.draw.line(
                screen,
                WHITE,
                (mine.right, mine.top),
                (mine.left, mine.bottom),
                3
            )

        # Bullets
        for bullet in bullets:
            pygame.draw.rect(screen, BLUE, bullet)

        # Scoreboard
        draw_text(f"Score: {score}", 20, 20)
        draw_text(f"Lives: {lives}", 20, 60)
        draw_text(f"Time: {time_left}", 20, 100)

        magnet_text = "MAGNET: ON" if magnet else "MAGNET: OFF"
        magnet_color = BLUE if magnet else RED

        draw_text(magnet_text, 650, 20, magnet_color)
        draw_text("SPACE: Magnet | F: Laser", 280, 20)

        # Game over screen
        if game_over:

            overlay = pygame.Surface((WIDTH, HEIGHT))
            overlay.set_alpha(210)
            overlay.fill(BLACK)

            screen.blit(overlay, (0, 0))

            draw_text(
                "GAME OVER",
                300,
                200,
                RED,
                big_font
            )

            draw_text(
                f"Final Score: {score}",
                350,
                280
            )

            draw_text(
                "Press R to Restart",
                330,
                340
            )

        pygame.display.flip()

        # Required for Pygbag browser compatibility
        await asyncio.sleep(0)


asyncio.run(main())
